let arrayPinguini = [];
let arrayManeskin = [];
let arrayMahmood = [];
document.addEventListener("DOMContentLoaded", async() => {
    await new Promise(function async(resolve, myReject) {
        fetch('https://striveschool-api.herokuapp.com/api/deezer/search?q=pinguini%20tattici%20nucleari').then(async (response) => {
            await response.json().then(async (dati) => {
                arrayPinguini = await dati.data;
                resolve();
            });
        }).catch((err) => { console.log(err); });
    });
    await new Promise(function async(resolve, myReject) {
        fetch('https://striveschool-api.herokuapp.com/api/deezer/search?q=maneskin').then(async (response) => {
            await response.json().then(async (dati) => {
                arrayManeskin = await dati.data;
                resolve();
            })
        }).catch((err) => { console.log(err); });
    });
    await new Promise(function async(resolve, myReject) {
        fetch('https://striveschool-api.herokuapp.com/api/deezer/search?q=mahmood').then(async (response) => {
            await response.json().then(async (dati) => {
                arrayMahmood = await dati.data;
                resolve();
            })
        }).catch((err) => { console.log(err); });
    });
})
function search() {
    let valueSearch = document.getElementById("searchField").value;
    if (valueSearch === "pinguini tattici nucleari") {
        popDom(arrayPinguini);
    } else if (valueSearch === "maneskin") {
        popDom(arrayManeskin);
    } else if (valueSearch === "mahmood") {
        popDom(arrayMahmood);
    }
}

function popDom(arr) {
    let arrayDati = arr;
    let cont = document.getElementById("contCards");
    cont.innerHTML = "";
    let row = document.createElement("div");
    cont.appendChild(row);
    arrayDati.forEach((item, i) => {
        let card = document.createElement("div");
        let imgCard = document.createElement("img");
        let cardBody = document.createElement("div");
        let album = document.createElement("h6");
        let track = document.createElement("h6");
        let text1 = document.createElement("p");
        let text2 = document.createElement("p");
        row.classList.add("row", "justify-content-between");
        card.classList.add("card","col-6", "col-sm-6", "col-md-4", "col-lg-3");
        card.style.margin = ("20px 0px");
        card.style.maxWidth = ("230px");
        imgCard.classList.add("card-img-top", "img-fluid");
        cardBody.classList.add("card-body");
        album.classList.add("card-title","text-center");
        track.classList.add("card-title","text-center");
        text1.innerText = "Album:";
        text2.innerText = "Track:";
        text1.style.fontSize = "0,8rem";
        text2.style.fontSize = "0,8rem";
        text1.style.margin = "0,8rem";
        text2.style.margin = "0,8rem";
        row.appendChild(card);
        card.appendChild(imgCard);
        card.appendChild(cardBody);
        cardBody.appendChild(text1);
        cardBody.appendChild(album);
        cardBody.appendChild(text2);
        cardBody.appendChild(track);
        imgCard.src = item.album.cover_big;
        album.innerText = (item.album.title);
        track.innerText = (item.title);
    })
}

function tuttiAlbum(){
    let arrayDatiManesk = arrayManeskin;
    let arrayDatiMahmoo = arrayMahmood;
    let arrayDatiPinguini = arrayPinguini;


    
    let cont = document.getElementById("contCards");
    cont.innerHTML = "";
    let row = document.createElement("div");
    cont.appendChild(row);
    arrayDatiManesk.forEach((item, i) => {
        let card = document.createElement("div");
        let imgCard = document.createElement("img");
        let cardBody = document.createElement("div");
        let album = document.createElement("h6");
        let track = document.createElement("h6");
        let text1 = document.createElement("p");
        let text2 = document.createElement("p");
        row.classList.add("row", "justify-content-between");
        card.classList.add("card","col-6", "col-sm-6", "col-md-4", "col-lg-3");
        card.style.margin = ("20px 0px");
        card.style.maxWidth = ("230px");
        imgCard.classList.add("card-img-top", "img-fluid");
        cardBody.classList.add("card-body");
        album.classList.add("card-title","text-center");
        track.classList.add("card-title","text-center");
        text1.innerText = "Album:";
        text2.innerText = "Track:";
        text1.style.fontSize = "0,8rem";
        text2.style.fontSize = "0,8rem";
        text1.style.margin = "0,8rem";
        text2.style.margin = "0,8rem";
        row.appendChild(card);
        card.appendChild(imgCard);
        card.appendChild(cardBody);
        cardBody.appendChild(text1);
        cardBody.appendChild(album);
        cardBody.appendChild(text2);
        cardBody.appendChild(track);
        imgCard.src = item.album.cover_big;
        album.innerText = (item.album.title);
        track.innerText = (item.title);
    })



    let row2 = document.createElement("div");
    cont.appendChild(row2);
    arrayDatiMahmoo.forEach((item, i) => {
        let card = document.createElement("div");
        let imgCard = document.createElement("img");
        let cardBody = document.createElement("div");
        let album = document.createElement("h6");
        let track = document.createElement("h6");
        let text1 = document.createElement("p");
        let text2 = document.createElement("p");
        row2.classList.add("row", "justify-content-between");
        card.classList.add("card","col-6", "col-sm-6", "col-md-4", "col-lg-3");
        card.style.margin = ("20px 0px");
        card.style.maxWidth = ("230px");
        imgCard.classList.add("card-img-top", "img-fluid");
        cardBody.classList.add("card-body");
        album.classList.add("card-title","text-center");
        track.classList.add("card-title","text-center");
        text1.innerText = "Album:";
        text2.innerText = "Track:";
        text1.style.fontSize = "0,8rem";
        text2.style.fontSize = "0,8rem";
        text1.style.margin = "0,8rem";
        text2.style.margin = "0,8rem";
        row2.appendChild(card);
        card.appendChild(imgCard);
        card.appendChild(cardBody);
        cardBody.appendChild(text1);
        cardBody.appendChild(album);
        cardBody.appendChild(text2);
        cardBody.appendChild(track);
        imgCard.src = item.album.cover_big;
        album.innerText = (item.album.title);
        track.innerText = (item.title);
    })


    let row3 = document.createElement("div");
    cont.appendChild(row3);
    arrayDatiPinguini.forEach((item, i) => {
        let card = document.createElement("div");
        let imgCard = document.createElement("img");
        let cardBody = document.createElement("div");
        let album = document.createElement("h6");
        let track = document.createElement("h6");
        let text1 = document.createElement("p");
        let text2 = document.createElement("p");
        row3.classList.add("row3", "justify-content-between");
        card.classList.add("card","col-6", "col-sm-6", "col-md-4", "col-lg-3");
        card.style.margin = ("20px 0px");
        card.style.maxWidth = ("230px");
        imgCard.classList.add("card-img-top", "img-fluid");
        cardBody.classList.add("card-body");
        album.classList.add("card-title","text-center");
        track.classList.add("card-title","text-center");
        text1.innerText = "Album:";
        text2.innerText = "Track:";
        text1.style.fontSize = "0,8rem";
        text2.style.fontSize = "0,8rem";
        text1.style.margin = "0,8rem";
        text2.style.margin = "0,8rem";
        row.appendChild(card);
        card.appendChild(imgCard);
        card.appendChild(cardBody);
        cardBody.appendChild(text1);
        cardBody.appendChild(album);
        cardBody.appendChild(text2);
        cardBody.appendChild(track);
        imgCard.src = item.album.cover_big;
        album.innerText = (item.album.title);
        track.innerText = (item.title);
    })
}

function unici(){
    console.log(arrayMahmood);

}